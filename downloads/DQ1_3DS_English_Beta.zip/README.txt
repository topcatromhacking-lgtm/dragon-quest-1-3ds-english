DRAGON QUEST I - ENGLISH TRANSLATION FOR NINTENDO 3DS
Beta - TopCatHack (2026)

This package is for the Japanese Nintendo 3DS game.
Included Title ID: 00040000001C3700.
The same files are used by Azahar and Luma3DS. No CIA rebuilding is needed.

AZAHAR (WINDOWS)

Close the game and extract this ZIP. In Azahar's game list, right-click
Dragon Quest I and select Open Mods Location (or Open > Mods Location).

Copy code.ips and the romfs folder FROM INSIDE 00040000001C3700 into
the folder Azahar opens. Do not put another Title ID folder inside it.
The resulting paths should end in:

load/mods/00040000001C3700/code.ips
load/mods/00040000001C3700/romfs/retro1_res.dat

Launch the Japanese game normally. If an older translation is installed,
replace its files and remove any old code.bin from this game's mod folder
so it does not conflict with code.ips. Keep a backup of any other mods.

LUMA3DS (REAL NINTENDO 3DS / 2DS)

You need a console already running Luma3DS and your Japanese game installed.
Turn the console off, insert its SD card into your computer, and extract
this ZIP. Copy the entire 00040000001C3700 folder into /luma/titles/ on
the SD card. Create the titles folder if necessary.

The final paths must be:

SD:/luma/titles/00040000001C3700/code.ips
SD:/luma/titles/00040000001C3700/romfs/retro1_res.dat

Remove any old code.bin from this game's patch folder. Safely eject the
SD card and reinsert it. Hold SELECT while powering on to open Luma's
configuration, enable game patching, and use the on-screen save-and-exit
command (normally START). Launch Dragon Quest I from the HOME Menu.

This beta has been tested in Azahar. Real hardware testing remains pending.

UPDATING AND REMOVING

Close the game before replacing patch files. Back up your normal in-game
saves before testing. To disable the translation, move this game's code.ips
and romfs folder out of its mod directory; leave other games' mods alone.
This does not uninstall the game or delete its saves.

TROUBLESHOOTING

If the game stays Japanese, check that both files are in the exact paths
above, that the Title ID matches your game, and that Luma game patching is
on when using real hardware. Do not install code.bin alongside code.ips.

For a freeze or layout problem, report the patch version, game location,
steps to reproduce it, and a screenshot. Include a normal save if possible.
Early testing passed, but a full playthrough remains pending. Some text
may overflow its intended space.

CREDITS

Assembly, interface translation, adaptation and testing: TopCatHack (2026).
Official English script adapted from the Nintendo Switch release.
Original game and localization: Square Enix and the original teams.
AI assisted with technical analysis, patch development and troubleshooting.

Free, unofficial fan project. Do not sell this patch.
Dragon Quest belongs to its respective rights holders.

Installation reference:
https://github.com/LumaTeam/Luma3DS/wiki/Optional-features
https://citra.azahar-emu.org/help/feature/game-modding/
